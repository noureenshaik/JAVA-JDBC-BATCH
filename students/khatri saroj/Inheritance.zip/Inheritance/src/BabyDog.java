class BabyDog extends Dog2{
    void weep()
    {
        System.out.println("weeping...");}
}

