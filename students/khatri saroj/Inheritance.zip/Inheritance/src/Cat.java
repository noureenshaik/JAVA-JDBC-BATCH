class Cat extends Animal3{
    void meow(){System.out.println("meowing...");}
}