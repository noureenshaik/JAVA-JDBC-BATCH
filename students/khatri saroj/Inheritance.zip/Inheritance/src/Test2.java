public class Test2 {
    public static void main(String args[])
    {

        MountainBike2 mb = new MountainBike2 (3, 100, 25);
        System.out.println(mb.toString());
    }
}
