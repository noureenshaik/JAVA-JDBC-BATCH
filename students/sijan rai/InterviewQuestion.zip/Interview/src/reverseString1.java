package com.Interview;

public class reverseString1 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        String str="Sijan Rai";
        char chars[]=str.toCharArray();
        for(int i=chars.length-1; i>=0; i--) {
            System.out.print(chars[i]);
        }
    }

}