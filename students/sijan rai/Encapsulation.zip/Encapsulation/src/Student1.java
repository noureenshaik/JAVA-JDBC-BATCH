public class Student1{

    private String college="AKG";

    public String getCollege(){
        return college;
    }
}
