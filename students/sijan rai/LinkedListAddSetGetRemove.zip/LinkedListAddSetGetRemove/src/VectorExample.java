package LinkedListAddSetGetRemove;
import java.util.*;

public class VectorExample {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        //create a vector class
        Vector<String> vec = new Vector<String>();
        //adding elements ussing add() method of list
        vec.addElement("Tiger");
        vec.addElement("Lion");
        vec.addElement("Bear");
        vec.addElement("Elephant");

        //adding elements using addElement() method of vector
        vec.addElement("Rat");
        vec.addElement("Cat");
        vec.addElement("Dog");

        System.out.println("Elements are: "+vec);


    }

}