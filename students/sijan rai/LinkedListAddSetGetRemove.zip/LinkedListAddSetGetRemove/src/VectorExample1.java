

package LinkedListAddSetGetRemove;
import java.util.*;

public class VectorExample1 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        //create an empty vector with initial capacity 4
        Vector<String> vec = new Vector<String>(6);
        //adding elements to a vector
        vec.add("Tiger");
        vec.add("Lion");
        vec.add("Dog");
        vec.add("Elephant");

    }

}
