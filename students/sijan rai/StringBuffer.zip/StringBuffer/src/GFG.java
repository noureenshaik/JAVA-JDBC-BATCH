class GFG {
    public static void main(String[] args)
    {

        StringBuilder
                str
                = new StringBuilder("WelcomeGeeks");

        System.out.println("String is "
                + str.toString());

        for (int i = 0; i < str.length(); i++) {

            char ch = str.charAt(i);

            System.out.println("Char at position "
                    + i + " is " + ch);
        }
    }
}
