package ArrayList;

import java.util.*; //import java.util.Arraylist;

public class FirstList {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ArrayList<String> list = new ArrayList<String>();

        list.add("Mango");
        list.add("Apple");
        list.add("Banana");

        for (String fruit : list)
            System.out.println(fruit);

        System.out.println(list);
    }

}