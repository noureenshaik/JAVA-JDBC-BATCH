import java. time.*;
public class Exercise6 {
    public static void main(String[] args)
    {
        Instant timestamp = Instant.now();
        System.out.println("\nCurrent Timestamp: " + timestamp+"\n");
    }
}

