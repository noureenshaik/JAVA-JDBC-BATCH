//Assignment 4 :A passenger of Kaveri travels can travel by two types of ticket reservations,
        //Confirmed ticket and Requested ticket. The Travel Reservation has various
       // Attributes, such as bus service number, date, time and destination. Both types of classes inherit these common
       // attributes. The Confirmed ticket class would however have a seat number while a Requested ticket would have a
       // status attribute. Draw the class hierarchy diagram for the three class depicting the inherited attributes of the sub
        //classes and their individual attributes.
import java.util.Scanner;
class RequestedTicket {
    void request() {
        Scanner rt = new Scanner(System.in);
        System.out.println("Check Available Tickets");
        int avalibility = rt.nextInt();
        if (avalibility == 1) {
            System.out.println("First Class Available");
            System.out.println("Enter your Name");
            String pname = rt.next();
            System.out.println("Enter your Phone Number");
            double pno = rt.nextDouble();
            System.out.println("Your ticket is Requested");
        } else if (avalibility == 2) {
            System.out.println("Not Available");
        }
    }
}
class ConformedTicket extends RequestedTicket {
    static int seatno;
    static double Phonenumber;
    static String name;

    void conformed() {
        Scanner ct = new Scanner(System.in);
        ConformedTicket bc = new ConformedTicket();
        System.out.println("Check Available Tickets");
        int avalibility = ct.nextInt();
        if (avalibility == 1) {
            System.out.println("Enter your Name");
            String pname = ct.next();
            name = pname;
            System.out.println("Enter your Phone Number");
            double pno = ct.nextDouble();
            Phonenumber = pno;
            System.out.println("Available seat numbers are 20" + "\n"
                    + "Enter your Desired Seat Number");
            int sno = ct.nextInt();
            if (sno >= 1 && sno <= 20) {
                seatno = sno;
                System.out.println("Your ticket is Conformed");
                System.out.println(KaveriTravels.sdestination + "\n" + KaveriTravels.stime + "\n" + KaveriTravels.sdate + "\n" +
                        ConformedTicket.seatno);
                System.out.println(ConformedTicket.name + "\n" + ConformedTicket.Phonenumber);
            } else {
                System.out.println("Not applicable");
            }
        } else if (avalibility == 2) {
            System.out.println("Tickets not Available" + "\n" + "Waiting list");
            bc.request();//calling request method
        }
    }
}
