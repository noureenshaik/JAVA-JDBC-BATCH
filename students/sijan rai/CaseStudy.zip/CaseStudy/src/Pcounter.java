//Assignment 1 :
//In an outlet, there can be several counters, each one managed by a single
//Sales person selling a specific product . A customer approaches any counter, depending on the product the customer
//wishes to purchase. The salesperson hands over the product and accepts the payment from the customer. Identify the
//classes, their attributes and operations in that classes

import java.util.Scanner;
abstract class Pcounter {
    abstract void process();
}
class Counterone extends Pcounter {
    Scanner p1 = new Scanner(System.in);
    int Payment, Receipt;
    @Override
    void process() {
        System.out.println("Cost of the Product is $100");
        System.out.println("Enter Payment Status"+"\n"+"1.Done"+"\n"+"2.Not Done");
        Payment = p1.nextInt();
        if (Payment == 1) {
            System.out.println("Payment done");
            System.out.println("Enter Receipt Status"+"\n"+"1.Done"+"\n"+"2.Not Done");
            Receipt = p1.nextInt();
            if (Receipt == 1) {
                System.out.println("Receipt Given");
                System.out.println("Your produt is:"+ProductCounters.productno+"\n"+"Payment done"+"\n"+"Receipt Given");
            } else if (Receipt == 2) {
                System.out.println("Receipt Not Given");
            }
        } else if (Payment == 2) {
            System.out.println("Payment not done");
        }
    }
}
class Countertwo extends Pcounter {
    Scanner p2 = new Scanner(System.in);
    int Payment, Receipt;
    @Override
    void process() {
        System.out.println("Cost of the Product is $200");
        System.out.println("Enter Payment Type Status"+"\n"+"1.Done"+"\n"+"2.Not Done");
        Payment = p2.nextInt();
        if (Payment == 1) {
            System.out.println("Payment done");
            System.out.println("Enter Receipt Status"+"\n"+"1.Done"+"\n"+"2.Not Done");
            Receipt = p2.nextInt();
            if (Receipt == 1) {
                System.out.println("Receipt Given");
                System.out.println("Your produt is:"+ProductCounters.productno+"\n"+"Payment done"+"\n"+"Receipt Given");
            } else if (Receipt == 2) {
                System.out.println("Receipt not Given");
            }
        } else if (Payment == 2) {
            System.out.println("Payment not done");
        }
    }
}
class Counterthree extends Pcounter {
    Scanner p3 = new Scanner(System.in);
    int Payment, Receipt;
    @Override
    void process() {
        System.out.println("Cost of the Product is $300");
        System.out.println("Enter Payment Status"+"\n"+"1.Done"+"\n"+"2.Not Done");
        Payment = p3.nextInt();
        if (Payment == 1) {
            System.out.println("Payment done");
            System.out.println("Enter Receipt Status"+"\n"+"1.Done"+"\n"+"2.Not Done");
            Receipt = p3.nextInt();
            if (Receipt == 1) {
                System.out.println("Receipt Given");
                System.out.println("Your produt is:"+ProductCounters.productno+"\n"+"Payment done"+"\n"+"Receipt Given");
            } else if (Receipt == 2) {
                System.out.println("Receipt not Given");
            }
        } else if (Payment == 2) {
            System.out.println("Payment not done");
        }
    }
}
