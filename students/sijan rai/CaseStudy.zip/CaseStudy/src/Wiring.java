import java.util.Scanner;
class Wiring {//using encapsulation
    private String wiringType;
    public String wiringType() {
        return wiringType;
    }
    public String getWiringType() {
        return wiringType;
    }
    public void setWiringType(String wiringType) {
        this.wiringType = wiringType;
    }
}

