class Axis extends Bank{
    int getRateOfInterest(){return 8;}
}

