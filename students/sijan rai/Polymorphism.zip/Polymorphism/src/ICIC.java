class ICIC extends Bank{
    int getRateOfInterest(){return 8;}
}
