class Bank{
    int getRateOfInterest(){return 0;}
}

