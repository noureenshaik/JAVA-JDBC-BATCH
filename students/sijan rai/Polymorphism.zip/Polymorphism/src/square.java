class square extends Polygon {

    public void render() {
        System.out.println("Rendering Square...");
    }
}
