class circle extends Polygon {

    public void render() {
        System.out.println("Rendering Circle...");
    }
}

