class Language {
    public void displayInfo() {
        System.out.println("Common English Language");
    }
}

