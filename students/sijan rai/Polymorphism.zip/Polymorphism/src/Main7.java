class Main7 {
    public static void main(String[] args) {
        Pattern d1 = new Pattern();

        d1.display();
        System.out.println("\n");

        d1.display('#');
    }
}
