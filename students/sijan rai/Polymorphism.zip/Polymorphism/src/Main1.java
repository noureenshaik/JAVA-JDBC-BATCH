class Main1 {
    public static void main(String[] args) {

        square s1 = new square();
        s1.render();

        circle c1 = new circle();
        c1.render();
    }
}
