class Main6{
    public static void main(String[] args){
        System.out.println(Adder1.add(11,11));
        System.out.println(Adder1.add(12.3,12.6));
    }
}
