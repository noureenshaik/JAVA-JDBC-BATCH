class Polygon {

    public void render() {
        System.out.println("Rendering Polygon...");
    }
}
