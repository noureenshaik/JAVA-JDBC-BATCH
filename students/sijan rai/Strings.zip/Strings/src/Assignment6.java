public class Assignment6
{
    public static void main(String ar[])
    {
        String s=" Sijan ";
        System.out.println(s);
        System.out.println(s.trim());
    }
}
