public class Assignment8
{
    public static void main(String ar[])
    {
        String s="Sijan";
        System.out.println(s.charAt(0));//S
        System.out.println(s.charAt(3));//h
    }
}
