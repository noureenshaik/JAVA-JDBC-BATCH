public class Assignment7
{
    public static void main(String ar[])
    {
        String s="Sijan";
        System.out.println(s.startsWith("Si"));//true
        System.out.println(s.endsWith("n"));//true
    }
}

