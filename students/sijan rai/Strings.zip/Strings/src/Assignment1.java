class Assignment1 {
    public static void main(String[] args) {

        // create strings
        String first = "Java";
        String second = "Python";
        String third = "JavaScript";

        // print strings
        System.out.println(first);   // print Java
        System.out.println(second);  // print Python
        System.out.println(third);   // print JavaScript
    }
}
