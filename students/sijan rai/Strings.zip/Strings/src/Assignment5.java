public class Assignment5
{
    public static void main(String ar[])
    {
        String s="Sijan";
        System.out.println(s.toUpperCase());
        System.out.println(s.toLowerCase());
        System.out.println(s);
    }
}
